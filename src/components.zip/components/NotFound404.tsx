const NotFound404 = () => {
  return (
    <div className='text-white' >NotFound404</div>
  )
}

export default NotFound404